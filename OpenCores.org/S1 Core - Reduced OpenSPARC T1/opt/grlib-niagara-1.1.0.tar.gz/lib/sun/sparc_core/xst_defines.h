`define FPGA_SYN
`define FPGA_SYN_NO_SPU
`define FPGA_SYN_1THREAD
`define NO_SCAN
`define FPGA_SYN_CLK
`define FPGA_SYN_CLK_DFF
`define FPGA_SYN_CLK_EN
