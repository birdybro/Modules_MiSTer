void initTTY();
void SetTextColor(unsigned char c);
