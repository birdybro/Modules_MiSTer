
This T1 Niagara design is tailored to the Avnet Virtex4 Evaluation board:

http://www.em.avnet.com/evk/home/0,1719,RID%253D0%2526CID%253D16863%2526CCD%253DUSA%2526SID%253D4746%2526DID%253DDF2%2526SRT%253D1%2526LID%253D0%2526PRT%253D0%2526PVW%253D%2526BID%253DDF2%2526CTP%253DEVK,00.html

Design specifics:

* System reset is mapped to SW3

* LED 6 and 7 indicates UART RX and TX activity.

* The serial port is connected to the console UART (UART 1)

* The GRETH core is enabled and runs without problems at 100 Mbit.
  Ethernet debug link is enabled, default IP is 192.168.0.69.

* 16-bit flash prom can be read at address 0. It can be programmed
  with GRMON version 1.1.14a or later.

* DDR is mapped at address 0x40000000 (32 Mbyte). It can run at 
  90 - 130 MHz. The processor and AMBA system runs on a different
  clock, and can typically reach 30 - 40 MHz.
